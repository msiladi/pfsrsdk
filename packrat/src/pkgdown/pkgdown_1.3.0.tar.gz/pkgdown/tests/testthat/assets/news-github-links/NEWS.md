# pkgdown 0.1.0

## Major changes

- Bug fixes (@hadley, #100)

- Merges (@josue-rodriguez)
