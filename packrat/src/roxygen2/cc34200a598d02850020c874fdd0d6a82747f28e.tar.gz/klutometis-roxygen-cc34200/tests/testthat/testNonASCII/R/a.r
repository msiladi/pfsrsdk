#' 中文注释
#'
#' @note 我爱中文。
printChineseMsg <- function() {
  message("我是UTF8的中文字符。")
}
