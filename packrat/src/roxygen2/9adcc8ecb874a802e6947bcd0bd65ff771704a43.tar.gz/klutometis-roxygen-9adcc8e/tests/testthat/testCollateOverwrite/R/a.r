#' @include b.r
a <- 1
