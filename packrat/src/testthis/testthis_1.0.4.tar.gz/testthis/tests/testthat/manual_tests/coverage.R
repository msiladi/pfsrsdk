x <- testthis::get_test_coverage()

x

as.data.frame(x)
