context("test_get_pkg_tested_functions")

test_that("fizzfun works as expected", {

})

test_that(
  "buzzfun works as expected", {
})


test_that(
  code = 'bummer',
  desc = "even foofun is found")


test_that(
  code = expect_true(FALSE),
  "%barfun% is ok")
