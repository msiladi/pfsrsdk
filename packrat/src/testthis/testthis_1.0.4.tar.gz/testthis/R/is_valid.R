is_valid <- function(dat){
  UseMethod('is_valid')
}
